// MCPL Season 2 starter app. Replace the Firebase config values before use.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getDatabase, ref, onValue, push, set, update, remove, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js';

const firebaseConfig = {
  apiKey: 'PASTE_API_KEY',
  authDomain: 'PASTE_PROJECT_ID.firebaseapp.com',
  databaseURL: 'https://PASTE_DATABASE_NAME-default-rtdb.firebaseio.com',
  projectId: 'PASTE_PROJECT_ID',
  appId: 'PASTE_APP_ID'
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const $ = id => document.getElementById(id);
let user = null, isAdmin = false, myTeamId = null, state = {}, players = {}, teams = {}, requests = {};
let unsubscribers = [];
const money = n => '₹' + Number(n || 0).toLocaleString('en-IN');
const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function clearListeners(){ unsubscribers.forEach(fn => fn()); unsubscribers=[]; }
function listen(path, cb){ const unsub=onValue(ref(db,path), snap=>{cb(snap.val() || {}); render();}, err=>showError(err.message)); unsubscribers.push(unsub); }
function showError(msg){ $('login-error').textContent=msg; $('bid-feedback').textContent=msg; }
$('login-form').addEventListener('submit', async e=>{e.preventDefault(); showError(''); try{await signInWithEmailAndPassword(auth,$('email').value.trim(),$('password').value);}catch(err){showError(err.message);} });
$('signout').addEventListener('click',()=>signOut(auth));
onAuthStateChanged(auth, async current=>{
  clearListeners(); user=current; isAdmin=false; myTeamId=null;
  $('login-panel').hidden=!!current; $('app-panel').hidden=!current;
  if(!current) return;
  $('uid-display').textContent='UID: '+current.uid;
  $('identity').textContent=current.email || 'Signed-in user';
  // Admin status is defined by the admin UID configured in Realtime Database rules and /config/adminUid.
  // The DB rule is the real security boundary; this UI flag only changes what controls are shown.
  listen('config', val=>{state=val; isAdmin=val.adminUid===current.uid; $('identity').textContent=(isAdmin?'AUCTIONEER · ':'CAPTAIN / VIEWER · ')+(current.email||'Account'); $('admin-controls').hidden=!isAdmin; $('captain-controls').hidden=isAdmin; });
  listen('current', val=>state.current=val);
  listen('players', val=>players=val);
  listen('teams', val=>teams=val);
  listen('captainTeams', val=>myTeamId=val[current.uid] || null);
  listen('bidRequests', val=>requests=val);
});
function currentPlayer(){return players[state.current?.playerId] || null;}
function render(){
  if(!user) return;
  const p=currentPlayer(), cur=state.current||{};
  $('player-name').textContent=p?.name || 'Waiting for auctioneer';
  $('player-role').textContent=p ? `${p.role||'Player'} · Player ID ${p.id||'—'}` : 'Select a player to begin';
  $('base-price').textContent=money(p?.basePrice);
  $('current-bid').textContent=money(cur.bid);
  $('highest-team').textContent=teams[cur.teamId]?.name || 'No bids yet';
  $('player-status').textContent=cur.status || 'NOT STARTED';
  $('player-avatar').textContent=p?.emoji || '🏏';
  $('live-pill').textContent=cur.status==='LIVE'?'● LIVE AUCTION':'AUCTION ROOM';
  $('player-count').textContent=`${Object.keys(players).length} PLAYERS`;
  const bidInput=$('bid-amount');
  if(p && cur.status==='LIVE' && myTeamId && !isAdmin){bidInput.min=Number(cur.bid||p.basePrice)+Number(state.bidIncrement||500);bidInput.step=Number(state.bidIncrement||500);bidInput.value=bidInput.min;}
  $('teams-list').innerHTML=Object.entries(teams).map(([id,t])=>{const purse=Number(t.purse||0),spent=Number(t.spent||0),initial=Number(t.initialPurse||100000),pct=Math.max(0,Math.min(100,100*(initial-spent)/initial));return `<div class="team-card"><div class="team-top"><span class="team-name">${escapeHtml(t.name||id)}</span><span class="team-purse">${money(purse)}</span></div><div class="team-meta">Spent ${money(spent)} · ${Number(t.playersBought||0)} players</div><div class="purse-bar"><span style="width:${pct}%"></span></div></div>`;}).join('') || '<p class="muted">No teams configured yet. Add teams in the database setup steps.</p>';
  $('players-list').innerHTML=Object.entries(players).sort((a,b)=>Number(a[1].order||0)-Number(b[1].order||0)).map(([id,x])=>`<div class="player-chip"><strong>${escapeHtml(x.name)}</strong><span>${escapeHtml(x.role||'Player')} · ${money(x.basePrice)}</span><span class="${x.status==='SOLD'?'sold':x.status==='UNSOLD'?'unsold':''}">${escapeHtml(x.status||'AVAILABLE')}${x.soldTo?' · '+escapeHtml(teams[x.soldTo]?.name||x.soldTo):''}</span></div>`).join('') || '<p class="muted">Players will appear here.</p>';
  renderRequests();
}
function renderRequests(){
  if(!isAdmin){$('requests').innerHTML='<p class="muted small">Your captain team: '+escapeHtml(teams[myTeamId]?.name|| (myTeamId?'Team configured':'Not assigned yet'))+'. Bids require auctioneer confirmation.</p>';return;}
  const pending=Object.entries(requests).filter(([,r])=>r.status==='PENDING');
  $('requests').innerHTML=pending.map(([id,r])=>`<div class="request-card"><div><strong>${escapeHtml(teams[r.teamId]?.name||r.teamId)} · ${money(r.amount)}</strong><span class="muted small">${escapeHtml(r.playerName||'Player bid request')}</span></div><div class="request-actions"><button class="primary" data-approve="${id}">Approve</button><button class="secondary" data-reject="${id}">Reject</button></div></div>`).join('') || '<p class="muted">No pending requests.</p>';
  document.querySelectorAll('[data-approve]').forEach(b=>b.onclick=()=>approveRequest(b.dataset.approve));
  document.querySelectorAll('[data-reject]').forEach(b=>b.onclick=()=>update(ref(db,`bidRequests/${b.dataset.reject}`),{status:'REJECTED'}));
}
$('send-bid').addEventListener('click',async()=>{
  const p=currentPlayer(), cur=state.current||{}, amount=Number($('bid-amount').value);
  if(!myTeamId){$('bid-feedback').textContent='Your captain account is not assigned to a team yet. Ask the administrator.';return;}
  if(!p || cur.status!=='LIVE'){$('bid-feedback').textContent='No live player is open for bidding.';return;}
  const min=Number(cur.bid||p.basePrice)+Number(state.bidIncrement||500);
  if(!Number.isFinite(amount)||amount<min){$('bid-feedback').textContent=`Enter at least ${money(min)}.`;return;}
  if(amount>Number(teams[myTeamId]?.purse||0)){$('bid-feedback').textContent='Your team does not have enough purse for this bid.';return;}
  try{const requestRef=push(ref(db,'bidRequests'));await set(requestRef,{teamId:myTeamId,amount,playerId:cur.playerId,playerName:p.name,status:'PENDING',createdAt:serverTimestamp(),uid:user.uid});$('bid-feedback').textContent='Bid sent to auctioneer for approval.';}catch(err){$('bid-feedback').textContent=err.message;}
});
async function approveRequest(id){
  const r=requests[id], cur=state.current||{}, p=currentPlayer();
  if(!r||r.status!=='PENDING'||!p||cur.status!=='LIVE'||r.playerId!==cur.playerId){alert('This request is no longer valid.');return;}
  const min=Number(cur.bid||p.basePrice)+Number(state.bidIncrement||500), team=teams[r.teamId];
  if(Number(r.amount)<min){await update(ref(db,`bidRequests/${id}`),{status:'REJECTED',reason:'Bid below current minimum'});alert('A higher bid has already been approved.');return;}
  if(!team||Number(team.purse)<Number(r.amount)){await update(ref(db,`bidRequests/${id}`),{status:'REJECTED',reason:'Insufficient purse'});alert('Team purse is insufficient.');return;}
  // Operator approval is the single writer for the live auction state. Test carefully before a public event.
  await update(ref(db,`current`),{bid:Number(r.amount),teamId:r.teamId,lastBidAt:Date.now()});
  await update(ref(db,`bidRequests/${id}`),{status:'APPROVED'});
}
$('next-player').addEventListener('click',async()=>{
  if(!isAdmin)return;
  const available=Object.entries(players).filter(([,p])=>!['SOLD','UNSOLD'].includes(p.status)).sort((a,b)=>Number(a[1].order||0)-Number(b[1].order||0));
  if(!available.length){alert('No available players remain.');return;}
  const [id,p]=available[0];
  await update(ref(db,`players/${id}`),{status:'LIVE'});
  await set(ref(db,'current'),{playerId:id,bid:Number(p.basePrice||0),teamId:null,status:'LIVE',startedAt:Date.now()});
});
$('mark-unsold').addEventListener('click',async()=>{
  if(!isAdmin)return;const p=currentPlayer(),cur=state.current||{};if(!p)return;
  await update(ref(db,`players/${cur.playerId}`),{status:'UNSOLD'});await update(ref(db,'current'),{status:'UNSOLD'});
});
$('mark-sold').addEventListener('click',async()=>{
  if(!isAdmin)return;const p=currentPlayer(),cur=state.current||{};if(!p||!cur.teamId){alert('Approve a bid before marking this player SOLD.');return;}
  const team=teams[cur.teamId], price=Number(cur.bid||0);if(!team||Number(team.purse)<price){alert('Team purse validation failed.');return;}
  const updates={};updates[`players/${cur.playerId}/status`]='SOLD';updates[`players/${cur.playerId}/soldTo`]=cur.teamId;updates[`players/${cur.playerId}/soldPrice`]=price;updates[`teams/${cur.teamId}/purse`]=Number(team.purse)-price;updates[`teams/${cur.teamId}/spent`]=Number(team.spent||0)+price;updates[`teams/${cur.teamId}/playersBought`]=Number(team.playersBought||0)+1;updates['current/status']='SOLD';await update(ref(db),updates);
});
$('add-player-form').addEventListener('submit',async e=>{e.preventDefault();if(!isAdmin)return;const name=$('new-player-name').value.trim(),role=$('new-player-role').value,basePrice=Number($('new-player-base').value);if(!name||basePrice<=0)return;const playerRef=push(ref(db,'players'));await set(playerRef,{name,role,basePrice,status:'AVAILABLE',order:Object.keys(players).length+1,emoji:'🏏'});e.target.reset();$('new-player-base').value=1000;});
