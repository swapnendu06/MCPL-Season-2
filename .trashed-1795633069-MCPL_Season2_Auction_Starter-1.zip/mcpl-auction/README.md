# MCPL Season 2 — free live auction starter

A responsive web starter for a laptop/projector auctioneer screen and captain phones. It uses Firebase Authentication and Realtime Database. Captains submit bid requests; the auctioneer approves them before the live bid changes. The auctioneer confirms SOLD, which deducts the price from the team's purse.

## Important prototype limits

- This is a starter, not a fully audited production auction system. Test with dummy data before using it in a real tournament.
- The starter's client-side SOLD update is not an atomic server transaction. For a high-stakes auction, move approval and sale operations into a trusted server-side transaction (Cloud Functions generally requires a billing-enabled Firebase project) or a database with transactional RPC.
- The auctioneer must approve each bid request. This avoids allowing captains to write the live auction state directly.
- The UI currently supports adding players one at a time. For 100 players, use a prepared CSV-to-JSON import or add an import tool before event day.
- Do not publish your Firebase service-account credentials or admin password. Firebase web config is public by design; database rules are the security boundary.

## Setup

1. Create a Firebase project at https://console.firebase.google.com/ . Choose the no-cost Spark plan. Add a Web app and copy its config into `app.js`.
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. Create one auctioneer account and six captain accounts in **Authentication → Users**. Use temporary passwords and share each captain's account privately.
4. In **Realtime Database**, create the database and copy its database URL into `app.js` as `databaseURL`.
5. Find the auctioneer account's UID in Authentication → Users. Replace every `REPLACE_WITH_ADMIN_UID` in `database.rules.json` with that UID. Publish these rules.
6. In Realtime Database → Data, add this initial JSON under the root. Replace the sample team names with your actual names. The initial purse below is ₹100,000 per team; change it to your rules.

```json
{
  "config": {"adminUid": "REPLACE_WITH_ADMIN_UID", "bidIncrement": 500},
  "current": {"status": "NOT STARTED", "bid": 0, "playerId": null, "teamId": null},
  "teams": {
    "team1": {"name":"Team 1", "initialPurse":100000, "purse":100000, "spent":0, "playersBought":0},
    "team2": {"name":"Team 2", "initialPurse":100000, "purse":100000, "spent":0, "playersBought":0},
    "team3": {"name":"Team 3", "initialPurse":100000, "purse":100000, "spent":0, "playersBought":0},
    "team4": {"name":"Team 4", "initialPurse":100000, "purse":100000, "spent":0, "playersBought":0},
    "team5": {"name":"Team 5", "initialPurse":100000, "purse":100000, "spent":0, "playersBought":0},
    "team6": {"name":"Team 6", "initialPurse":100000, "purse":100000, "spent":0, "playersBought":0}
  },
  "players": {},
  "captainTeams": {},
  "bidRequests": {}
}
```

7. For each captain, sign in once and copy their UID from the top of the app. In the Realtime Database, add mappings under `captainTeams` using the captain UID as the key and the corresponding team ID as the value, for example `"CAPTAIN_UID_HERE": "team1"`. Only the admin can edit this mapping under the supplied rules.
8. Fill in `config.adminUid` with the auctioneer UID. Ensure it exactly matches the UID used in the database rules.
9. Serve the folder locally for testing: from this folder run `python -m http.server 8000`, then open `http://localhost:8000`. For captain-phone testing on the same Wi-Fi, use the laptop's LAN IP address and port 8000. This is only for local testing; for event use deploy over HTTPS.
10. Deploy to Firebase Hosting: install Node.js, then run `npm install -g firebase-tools`, `firebase login`, `firebase init hosting` (choose the existing project and this folder as public directory; configure as a single-page app: No), then `firebase deploy --only hosting`.
11. Test with a dummy player: captain requests a bid, auctioneer approves it, auctioneer confirms SOLD, and verify the purse decreases correctly. Test rejected bids, reloads, and multiple simultaneous requests.

## Adding the 100-player list

For the first rehearsal, use **Add player** to add a few dummy entries. Before the real auction, prepare a CSV with columns `name,role,basePrice,order`. A JSON import helper should validate names, positive base prices, unique order values, and avoid overwriting sold players. Do not paste 100 rows manually during the event.

## Event-day checklist

- Use a dedicated laptop and power adapter; test the projector at the actual resolution.
- Connect laptop and captains' phones to reliable Wi-Fi; keep a mobile hotspot as backup.
- Sign in and test each captain account, team mapping, base price, bid increment, and purse.
- Run a complete rehearsal with dummy players, including sold/unsold and a rejected bid.
- Keep an offline spreadsheet as the source-of-truth backup and record each sale.
